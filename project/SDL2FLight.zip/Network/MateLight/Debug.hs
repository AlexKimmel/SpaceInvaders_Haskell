{-# OPTIONS_HADDOCK hide #-}
module Network.MateLight.Debug where
import Prelude hiding (print)
import System.IO

debug :: String -> IO ()
debug _ = return ()
